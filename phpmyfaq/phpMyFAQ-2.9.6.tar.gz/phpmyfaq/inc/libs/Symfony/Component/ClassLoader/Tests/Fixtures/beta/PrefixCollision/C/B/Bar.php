<?php

class PrefixCollision_C_B_Bar
{
    public static $loaded = true;
}
