<?php

namespace ClassesWithParents;

trait BTrait
{
    use ATrait;
}
